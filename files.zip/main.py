from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
import httpx
import os
from dotenv import load_dotenv
import asyncio

# ============================================================================
# IMPORTS DO EXPORT
# ============================================================================

try:
    from export_data import (
        LEAGUES, DATA_TYPES, 
        get_fixtures, get_standings, get_top_scorers, get_injuries,
        save_csv, EXPORTS_DIR
    )
except ImportError:
    print("⚠️  export_data.py não encontrado. Endpoints de export desabilitados.")
    LEAGUES = {}
    DATA_TYPES = {}
    EXPORTS_DIR = None

# ============================================================================
# CONFIGURAÇÕES
# ============================================================================

load_dotenv()

API_KEY = os.getenv("API_KEY")
BASE_URL = "https://v3.football.api-sports.io"

if not API_KEY:
    raise ValueError("API_KEY não configurada no .env")

# ============================================================================
# INICIALIZAR APP
# ============================================================================

app = FastAPI(
    title="Football API",
    description="API para dados de futebol em tempo real",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3001", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cache em memória
cache = {}
CACHE_TTL = 3600  # 1 hora

# ============================================================================
# FUNÇÕES AUXILIARES
# ============================================================================

async def fazer_requisicao(endpoint: str, params: dict):
    """Fazer requisição à API-Football"""
    headers = {
        "x-apisports-key": API_KEY,
        "x-apisports-host": "v3.football.api-sports.io"
    }
    
    try:
        async with httpx.AsyncClient() as client:
            url = f"{BASE_URL}/{endpoint}"
            response = await client.get(url, params=params, headers=headers, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            remaining = response.headers.get("x-ratelimit-requests-remaining", "?")
            print(f"[API] {endpoint} | Rate limit: {remaining}")
            
            return data
    
    except Exception as e:
        print(f"[ERROR] Requisição falhou: {e}")
        return None

def get_cache_key(endpoint: str, params: dict) -> str:
    """Gerar chave de cache"""
    params_str = "_".join([f"{k}_{v}" for k, v in sorted(params.items())])
    return f"{endpoint}_{params_str}"

def is_cache_valid(key: str) -> bool:
    """Verificar se cache é válido"""
    if key not in cache:
        return False
    
    timestamp, _ = cache[key]
    if datetime.now().timestamp() - timestamp > CACHE_TTL:
        del cache[key]
        return False
    
    return True

# ============================================================================
# HEALTH CHECK
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check do backend"""
    return {
        "status": "online",
        "timestamp": datetime.now().isoformat(),
        "api_key_configured": bool(API_KEY)
    }

# ============================================================================
# ENDPOINTS PRINCIPAIS
# ============================================================================

@app.get("/fixtures/today")
async def get_fixtures_today():
    """Partidas de hoje"""
    today = datetime.now().strftime("%Y-%m-%d")
    
    params = {
        "date": today,
        "timezone": "America/Sao_Paulo"
    }
    
    cache_key = get_cache_key("fixtures", params)
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    result = await fazer_requisicao("fixtures", params)
    
    fixtures = []
    for fixture in result.get("response", []):
        fixtures.append({
            "id": fixture.get("id"),
            "league": fixture.get("league", {}).get("name"),
            "date": fixture.get("fixture", {}).get("date"),
            "status": fixture.get("fixture", {}).get("status", {}).get("short"),
            "home": {
                "name": fixture.get("teams", {}).get("home", {}).get("name"),
                "logo": fixture.get("teams", {}).get("home", {}).get("logo"),
            },
            "away": {
                "name": fixture.get("teams", {}).get("away", {}).get("name"),
                "logo": fixture.get("teams", {}).get("away", {}).get("logo"),
            },
            "goals": {
                "home": fixture.get("goals", {}).get("home"),
                "away": fixture.get("goals", {}).get("away"),
            },
        })
    
    response_data = {
        "fixtures": fixtures,
        "count": len(fixtures)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

@app.get("/fixtures/next")
async def get_fixtures_next(days: int = 7):
    """Próximas partidas"""
    today = datetime.now().strftime("%Y-%m-%d")
    future = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    
    params = {
        "from": today,
        "to": future,
        "timezone": "America/Sao_Paulo"
    }
    
    cache_key = get_cache_key("fixtures", params)
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    result = await fazer_requisicao("fixtures", params)
    
    fixtures = []
    for fixture in result.get("response", []):
        fixtures.append({
            "id": fixture.get("id"),
            "league": fixture.get("league", {}).get("name"),
            "date": fixture.get("fixture", {}).get("date"),
            "status": fixture.get("fixture", {}).get("status", {}).get("short"),
            "home": {
                "name": fixture.get("teams", {}).get("home", {}).get("name"),
                "logo": fixture.get("teams", {}).get("home", {}).get("logo"),
            },
            "away": {
                "name": fixture.get("teams", {}).get("away", {}).get("name"),
                "logo": fixture.get("teams", {}).get("away", {}).get("logo"),
            },
            "goals": {
                "home": fixture.get("goals", {}).get("home"),
                "away": fixture.get("goals", {}).get("away"),
            },
        })
    
    response_data = {
        "fixtures": fixtures,
        "count": len(fixtures)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

@app.get("/standings/{league_id}/{season}")
async def get_standings(league_id: str, season: str):
    """Tabela de classificação"""
    params = {
        "league": league_id,
        "season": season
    }
    
    cache_key = get_cache_key("standings", params)
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    result = await fazer_requisicao("standings", params)
    
    standings = []
    for league_standing in result.get("response", []):
        for standing in league_standing.get("standings", [{}])[0].get("table", []):
            standings.append({
                "position": standing.get("rank"),
                "team": standing.get("team", {}).get("name"),
                "logo": standing.get("team", {}).get("logo"),
                "played": standing.get("all", {}).get("played"),
                "wins": standing.get("all", {}).get("win"),
                "draws": standing.get("all", {}).get("draw"),
                "losses": standing.get("all", {}).get("lose"),
                "points": standing.get("points"),
                "goals_for": standing.get("all", {}).get("goals", {}).get("for"),
                "goals_against": standing.get("all", {}).get("goals", {}).get("against"),
            })
    
    response_data = {
        "standings": standings,
        "count": len(standings)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

@app.get("/players/topscorers/{league_id}/{season}")
async def get_top_scorers(league_id: str, season: str):
    """Artilheiros"""
    params = {
        "league": league_id,
        "season": season
    }
    
    cache_key = get_cache_key("topscorers", params)
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    result = await fazer_requisicao("players/topscorers", params)
    
    scorers = []
    for idx, player in enumerate(result.get("response", []), 1):
        stats = player.get("statistics", [{}])[0] if player.get("statistics") else {}
        scorers.append({
            "rank": idx,
            "player": player.get("player", {}).get("name"),
            "team": stats.get("team", {}).get("name"),
            "goals": stats.get("goals", {}).get("total"),
            "assists": stats.get("goals", {}).get("assists"),
            "appearances": stats.get("games", {}).get("appearences"),
        })
    
    response_data = {
        "scorers": scorers,
        "count": len(scorers)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

@app.get("/players/topassists/{league_id}/{season}")
async def get_top_assists(league_id: str, season: str):
    """Top assistentes"""
    params = {
        "league": league_id,
        "season": season
    }
    
    cache_key = get_cache_key("topassists", params)
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    result = await fazer_requisicao("players/topassists", params)
    
    assists = []
    for idx, player in enumerate(result.get("response", []), 1):
        stats = player.get("statistics", [{}])[0] if player.get("statistics") else {}
        assists.append({
            "rank": idx,
            "player": player.get("player", {}).get("name"),
            "team": stats.get("team", {}).get("name"),
            "goals": stats.get("goals", {}).get("total"),
            "assists": stats.get("goals", {}).get("assists"),
            "appearances": stats.get("games", {}).get("appearences"),
        })
    
    response_data = {
        "assists": assists,
        "count": len(assists)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

@app.get("/leagues")
async def get_leagues():
    """Lista de ligas"""
    cache_key = "leagues"
    if is_cache_valid(cache_key):
        _, data = cache[cache_key]
        return data
    
    params = {}
    result = await fazer_requisicao("leagues", params)
    
    leagues = []
    for league in result.get("response", []):
        if league.get("league", {}).get("id") in [39, 61, 78, 135, 71, 140]:
            leagues.append({
                "id": league.get("league", {}).get("id"),
                "name": league.get("league", {}).get("name"),
                "country": league.get("country", {}).get("name"),
                "logo": league.get("league", {}).get("logo"),
            })
    
    response_data = {
        "leagues": leagues,
        "count": len(leagues)
    }
    
    cache[cache_key] = (datetime.now().timestamp(), response_data)
    return response_data

# ============================================================================
# ENDPOINTS DE EXPORT (CSV)
# ============================================================================

@app.get("/export/leagues")
async def export_get_leagues():
    """Retorna lista de ligas disponíveis"""
    return {
        "leagues": [
            {
                "id": key,
                "name": value["name"],
                "country": value["country"]
            }
            for key, value in LEAGUES.items()
        ]
    }

@app.get("/export/data-types")
async def export_get_data_types():
    """Retorna tipos de dados disponíveis"""
    return {
        "types": [
            {
                "id": key,
                "name": value["name"],
                "endpoint": value["endpoint"],
                "fields": value["fields"]
            }
            for key, value in DATA_TYPES.items()
        ]
    }

@app.post("/export/fixtures")
async def export_fixtures(
    league_id: str = Query(...),
    season: str = Query(...),
    from_date: str = Query(...),
    to_date: str = Query(...)
):
    """Exportar fixtures e retornar CSV"""
    try:
        print(f"[EXPORT] Fixtures: Liga {league_id}, {from_date} a {to_date}")
        
        data = await get_fixtures(league_id, season, from_date, to_date)
        
        if not data:
            return {
                "success": False,
                "message": "Nenhum dado encontrado",
                "data": []
            }
        
        from datetime import datetime as dt
        timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{league_id}_fixtures_{season}_{timestamp}.csv"
        
        fields = DATA_TYPES["1"]["fields"]
        save_csv(data, filename, fields)
        
        return {
            "success": True,
            "message": f"{len(data)} fixtures exportadas com sucesso",
            "filename": filename,
            "data": data,
            "count": len(data)
        }
    
    except Exception as e:
        print(f"[ERROR] Export fixtures: {e}")
        return {
            "success": False,
            "message": f"Erro ao exportar: {str(e)}",
            "data": []
        }

@app.post("/export/standings")
async def export_standings(
    league_id: str = Query(...),
    season: str = Query(...)
):
    """Exportar tabela de classificação"""
    try:
        print(f"[EXPORT] Standings: Liga {league_id}, Temporada {season}")
        
        data = await get_standings(league_id, season)
        
        if not data:
            return {
                "success": False,
                "message": "Nenhum dado encontrado",
                "data": []
            }
        
        from datetime import datetime as dt
        timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{league_id}_standings_{season}_{timestamp}.csv"
        
        fields = DATA_TYPES["2"]["fields"]
        save_csv(data, filename, fields)
        
        return {
            "success": True,
            "message": f"{len(data)} times exportados com sucesso",
            "filename": filename,
            "data": data,
            "count": len(data)
        }
    
    except Exception as e:
        print(f"[ERROR] Export standings: {e}")
        return {
            "success": False,
            "message": f"Erro ao exportar: {str(e)}",
            "data": []
        }

@app.post("/export/topscorers")
async def export_topscorers(
    league_id: str = Query(...),
    season: str = Query(...)
):
    """Exportar artilheiros"""
    try:
        print(f"[EXPORT] Top Scorers: Liga {league_id}, Temporada {season}")
        
        data = await get_top_scorers(league_id, season)
        
        if not data:
            return {
                "success": False,
                "message": "Nenhum dado encontrado",
                "data": []
            }
        
        from datetime import datetime as dt
        timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{league_id}_topscorers_{season}_{timestamp}.csv"
        
        fields = DATA_TYPES["3"]["fields"]
        save_csv(data, filename, fields)
        
        return {
            "success": True,
            "message": f"{len(data)} artilheiros exportados com sucesso",
            "filename": filename,
            "data": data,
            "count": len(data)
        }
    
    except Exception as e:
        print(f"[ERROR] Export topscorers: {e}")
        return {
            "success": False,
            "message": f"Erro ao exportar: {str(e)}",
            "data": []
        }

@app.post("/export/injuries")
async def export_injuries(
    league_id: str = Query(...),
    season: str = Query(...)
):
    """Exportar lesões"""
    try:
        print(f"[EXPORT] Injuries: Liga {league_id}, Temporada {season}")
        
        data = await get_injuries(league_id, season)
        
        if not data:
            return {
                "success": False,
                "message": "Nenhum dado encontrado",
                "data": []
            }
        
        from datetime import datetime as dt
        timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{league_id}_injuries_{season}_{timestamp}.csv"
        
        fields = DATA_TYPES["4"]["fields"]
        save_csv(data, filename, fields)
        
        return {
            "success": True,
            "message": f"{len(data)} lesões exportadas com sucesso",
            "filename": filename,
            "data": data,
            "count": len(data)
        }
    
    except Exception as e:
        print(f"[ERROR] Export injuries: {e}")
        return {
            "success": False,
            "message": f"Erro ao exportar: {str(e)}",
            "data": []
        }

@app.get("/export/downloads")
async def export_list_downloads():
    """Listar arquivos exportados"""
    try:
        if not EXPORTS_DIR:
            return {"success": False, "exports": []}
        
        files = list(EXPORTS_DIR.glob("*.csv"))
        
        exports = []
        for file in sorted(files, reverse=True):
            exports.append({
                "filename": file.name,
                "size_kb": file.stat().st_size / 1024,
                "created": file.stat().st_mtime
            })
        
        return {
            "success": True,
            "exports": exports,
            "count": len(exports)
        }
    
    except Exception as e:
        print(f"[ERROR] List downloads: {e}")
        return {
            "success": False,
            "message": f"Erro ao listar arquivos: {str(e)}",
            "exports": []
        }

# ============================================================================
# ROOT
# ============================================================================

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "message": "Football API v1.0",
        "docs": "/docs",
        "health": "/health"
    }

# ============================================================================
# EXECUTAR
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
